#!/bin/bash

current_path="/root/LEGO/1_CRYSTAL_GENERATION/1_CRYSTAL_GENERATION"
present_path=$(pwd)

cd $current_path

$current_path/legoV3.1 $current_path/ex.confparam

#mv 

cp $current_path/header.txt $current_path/Ni_x101_z1-1-1.fcc

cat 111.fcc >> Ni_x101_z1-1-1.fcc

cp Ni_x101_z1-1-1.fcc output.xyz
